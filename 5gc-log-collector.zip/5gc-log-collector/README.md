# 5GC Log Collector

Mô phỏng hệ thống thu thập log HTTP tại các network function (NF) trong
mạng 5GC (AMF, SMF, UDM, NEF), tính toán thống kê thời gian thực: tổng
request/tỷ lệ lỗi theo API, độ trễ trung bình và p95 ước lượng, cùng
top-K IMSI/API xuất hiện nhiều nhất. Toàn bộ hệ thống chạy bằng Docker
Compose.

## Kiến trúc

```
Client simulator (nhiều goroutine, giả lập NF)
     | TCP (text line-based, đã batch)
     v
Server: TCP listener --> ingest channel --> worker pool
                                                 |
                                                 v
                                    Sharded store (counter, histogram, top-K)
                                                 |
                                                 v
                                    HTTP query API (/stats/...)
```

| Thành phần | Vai trò | Cổng (host) |
|---|---|---|
| `server` | Nhận log qua TCP, xử lý bằng worker pool, phục vụ query qua HTTP | `9000` (TCP), `8080` (HTTP) |
| `client` | Giả lập nhiều NF gửi log liên tục tới server | — |

## Yêu cầu

- Docker & Docker Compose
- (Tuỳ chọn) Go ≥ 1.22 nếu muốn chạy/sửa code ngoài container

## Cài đặt & chạy

1. Tạo file cấu hình từ mẫu:

   ```
   cp .env.example .env
   ```

   Mở `.env` để chỉnh số worker, kích thước buffer, số goroutine client,
   tốc độ gửi mục tiêu theo nhu cầu benchmark của bạn.

2. Build và khởi động toàn bộ hệ thống:

   ```
   docker compose up --build
   ```

3. Kiểm tra server đã nhận log:

   ```
   curl "http://localhost:8080/stats/api"
   ```

Ở các lần chạy sau (không sửa code), chỉ cần `docker compose up`, không cần `--build`.

**Đo hiệu năng đúng giới hạn 1vCPU/1GB:** `deploy.resources.limits` trong
`docker-compose.yml` chỉ có hiệu lực đầy đủ ở chế độ Swarm; khi benchmark
thật, nên chạy `server` bằng `docker run --cpus=1 --memory=1g ...` để chắc
chắn giới hạn được áp dụng, và chạy `client` trên máy/container khác để
không cạnh tranh CPU với server.

## API

### Thống kê theo API

```
GET /stats/api
```

Trả về tổng request, số lỗi (status ≥ 500), và tỷ lệ lỗi cho từng API.

### Độ trễ trung bình và p95

```
GET /stats/latency
```

Trả về số mẫu, độ trễ trung bình (ms), và p95 ước lượng (nội suy từ
histogram bucket cố định) cho từng API.

### Top-K IMSI / Top-K API

```
GET /stats/topk/imsi?k=10
GET /stats/topk/api?k=10
```

Trả về K IMSI hoặc API xuất hiện nhiều nhất, tính bằng min-heap trên
frequency map đã sharded — O(N log K) thay vì sort toàn bộ.

## Cấu trúc thư mục

```
5gc-log-collector/
├── protocol/            # định dạng log dùng chung giữa client và server
│   ├── protocol.go
│   └── protocol_test.go
├── server/               # server thu thập log
│   ├── main.go           # TCP listener + HTTP query API
│   ├── store/            # counter, histogram (p95), top-K (heap)
│   └── worker/           # worker pool: channel -> parse -> store
├── client/               # client giả lập NF sinh log
│   └── main.go
├── deployments/
│   ├── Dockerfile.server
│   └── Dockerfile.client
├── docker-compose.yml
├── .env.example
└── go.mod
```

## Kiểm thử

```
go test ./...
```

Bao gồm test round-trip cho protocol, và test cho thuật toán top-K/
histogram/counter bằng dữ liệu giả — không cần dựng server thật.

## Hạn chế đã biết

- p95 là giá trị ước lượng từ histogram bucket cố định, không phải giá trị
  chính xác tuyệt đối — đánh đổi để giữ chi phí ghi là O(1) ở tần suất cao.
- Chưa có graceful shutdown (xử lý `SIGTERM`) cho server.
- Dữ liệu chỉ lưu trong bộ nhớ, mất khi restart container.
