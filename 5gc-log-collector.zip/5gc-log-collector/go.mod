module 5gc-log-collector

go 1.22.2
