package store

import "sync/atomic"

// apiCounter giữ tổng số request và số request lỗi cho 1 API, cập nhật
// bằng atomic để không cần mutex — vì đây là số nguyên đơn giản, không
// phải cấu trúc phức hợp như map.
type apiCounter struct {
	total atomic.Int64
	errs  atomic.Int64
}

// CounterStore lưu counter cho toàn bộ API. Vì số lượng API trong hệ 5GC
// là cố định (đã liệt kê trong protocol.ValidAPIs), ta khởi tạo sẵn 1 map
// tĩnh lúc start-up — không phải tạo counter mới ở runtime, nên không cần
// lock khi truy cập map (chỉ ghi vào field bên trong struct đã tồn tại).
type CounterStore struct {
	counters map[string]*apiCounter
}

// NewCounterStore khởi tạo counter cho danh sách API cho trước.
func NewCounterStore(apis []string) *CounterStore {
	cs := &CounterStore{counters: make(map[string]*apiCounter, len(apis))}
	for _, api := range apis {
		cs.counters[api] = &apiCounter{}
	}
	return cs
}

// Observe ghi nhận 1 request cho api, đánh dấu lỗi nếu isError = true.
// Nếu api chưa từng được đăng ký trước (log lạ), bản ghi bị bỏ qua thay vì
// panic — server thu thập log không nên chết vì 1 dòng dữ liệu bất thường.
func (cs *CounterStore) Observe(api string, isError bool) {
	c, ok := cs.counters[api]
	if !ok {
		return
	}
	c.total.Add(1)
	if isError {
		c.errs.Add(1)
	}
}

// APIStat là kết quả trả về cho 1 API khi truy vấn.
type APIStat struct {
	API      string  `json:"api"`
	Total    int64   `json:"total"`
	Errors   int64   `json:"errors"`
	ErrRate  float64 `json:"error_rate"`
}

// Snapshot trả về thống kê hiện tại của toàn bộ API, dùng cho query API.
func (cs *CounterStore) Snapshot() []APIStat {
	out := make([]APIStat, 0, len(cs.counters))
	for api, c := range cs.counters {
		total := c.total.Load()
		errs := c.errs.Load()
		var rate float64
		if total > 0 {
			rate = float64(errs) / float64(total)
		}
		out = append(out, APIStat{API: api, Total: total, Errors: errs, ErrRate: rate})
	}
	return out
}
