package store

import (
	"container/heap"
	"hash/fnv"
	"sync"
)

// numShards chia frequency map thành nhiều phần để giảm tranh chấp lock
// khi hàng chục nghìn goroutine cùng tăng đếm mỗi giây. 32 là điểm khởi
// đầu hợp lý cho máy 1 vCPU; tăng lên nếu profiling cho thấy vẫn nghẽn ở
// đây (xem hướng dẫn đọc pprof).
const numShards = 32

type shard struct {
	mu    sync.RWMutex
	freq  map[string]int64
}

// TopKStore là 1 frequency counter được sharded, dùng cho cả top-K theo
// IMSI lẫn top-K theo API (khởi tạo 2 instance riêng biệt).
type TopKStore struct {
	shards [numShards]*shard
}

func NewTopKStore() *TopKStore {
	ts := &TopKStore{}
	for i := range ts.shards {
		ts.shards[i] = &shard{freq: make(map[string]int64)}
	}
	return ts
}

func (ts *TopKStore) shardFor(key string) *shard {
	h := fnv.New32a()
	_, _ = h.Write([]byte(key))
	return ts.shards[h.Sum32()%numShards]
}

// Increment tăng đếm cho key (IMSI hoặc tên API) lên 1.
func (ts *TopKStore) Increment(key string) {
	sh := ts.shardFor(key)
	sh.mu.Lock()
	sh.freq[key]++
	sh.mu.Unlock()
}

// KeyCount là 1 phần tử kết quả top-K.
type KeyCount struct {
	Key   string `json:"key"`
	Count int64  `json:"count"`
}

// minHeap là container/heap giữ tối đa k phần tử có count lớn nhất đã
// duyệt qua — bất kỳ lúc nào phần tử nhỏ nhất trong heap cũng nằm ở gốc,
// nên khi gặp phần tử mới lớn hơn gốc, chỉ cần thay gốc rồi sift-down.
// Độ phức tạp O(N log k) thay vì sort toàn bộ O(N log N).
type minHeap []KeyCount

func (h minHeap) Len() int            { return len(h) }
func (h minHeap) Less(i, j int) bool  { return h[i].Count < h[j].Count }
func (h minHeap) Swap(i, j int)       { h[i], h[j] = h[j], h[i] }
func (h *minHeap) Push(x interface{}) { *h = append(*h, x.(KeyCount)) }
func (h *minHeap) Pop() interface{} {
	old := *h
	n := len(old)
	item := old[n-1]
	*h = old[:n-1]
	return item
}

// TopK trả về k phần tử có đếm lớn nhất, sắp xếp giảm dần. Duyệt toàn bộ
// shard tại thời điểm gọi (snapshot), không khoá toàn cục — mỗi shard chỉ
// bị khoá đọc trong lúc duyệt riêng nó, nên không chặn các Increment đang
// diễn ra ở shard khác.
func (ts *TopKStore) TopK(k int) []KeyCount {
	if k <= 0 {
		return nil
	}
	h := &minHeap{}
	heap.Init(h)

	for _, sh := range ts.shards {
		sh.mu.RLock()
		for key, count := range sh.freq {
			if h.Len() < k {
				heap.Push(h, KeyCount{Key: key, Count: count})
			} else if count > (*h)[0].Count {
				heap.Pop(h)
				heap.Push(h, KeyCount{Key: key, Count: count})
			}
		}
		sh.mu.RUnlock()
	}

	// heap đang ở thứ tự min-first; đảo ngược để trả về giảm dần cho dễ đọc.
	result := make([]KeyCount, h.Len())
	for i := len(result) - 1; i >= 0; i-- {
		result[i] = heap.Pop(h).(KeyCount)
	}
	return result
}
