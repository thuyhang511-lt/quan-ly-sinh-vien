package store

import "5gc-log-collector/protocol"

// Store gộp toàn bộ cấu trúc thống kê lại làm một, để worker chỉ cần gọi
// 1 hàm Update() duy nhất sau khi parse xong 1 record.
type Store struct {
	Counters  *CounterStore
	Latencies *HistogramStore
	TopIMSI   *TopKStore
	TopAPI    *TopKStore
}

// New khởi tạo Store với danh sách API cố định lấy từ protocol.ValidAPIs.
func New() *Store {
	apis := allAPIs()
	return &Store{
		Counters:  NewCounterStore(apis),
		Latencies: NewHistogramStore(apis),
		TopIMSI:   NewTopKStore(),
		TopAPI:    NewTopKStore(),
	}
}

func allAPIs() []string {
	var apis []string
	for _, list := range protocol.ValidAPIs {
		apis = append(apis, list...)
	}
	return apis
}

// Update cập nhật toàn bộ cấu trúc thống kê từ 1 LogRecord đã parse xong.
// isError được tính từ status >= 500, theo đúng định nghĩa "lỗi" trong đề bài.
func (s *Store) Update(r protocol.LogRecord) {
	isError := r.Status >= 500
	s.Counters.Observe(r.API, isError)
	s.Latencies.Observe(r.API, r.Latency)
	s.TopIMSI.Increment(r.IMSI)
	s.TopAPI.Increment(r.API)
}
