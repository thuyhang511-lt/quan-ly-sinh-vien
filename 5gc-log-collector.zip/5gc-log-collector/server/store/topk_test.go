package store

import "testing"

func TestTopKReturnsHighestCounts(t *testing.T) {
	ts := NewTopKStore()

	// imsi-A xuất hiện 5 lần, imsi-B 3 lần, imsi-C 8 lần, imsi-D 1 lần.
	counts := map[string]int{
		"imsi-A": 5,
		"imsi-B": 3,
		"imsi-C": 8,
		"imsi-D": 1,
	}
	for key, n := range counts {
		for i := 0; i < n; i++ {
			ts.Increment(key)
		}
	}

	top := ts.TopK(2)
	if len(top) != 2 {
		t.Fatalf("kỳ vọng 2 phần tử, got %d", len(top))
	}
	if top[0].Key != "imsi-C" || top[0].Count != 8 {
		t.Fatalf("phần tử đầu sai: got %+v", top[0])
	}
	if top[1].Key != "imsi-A" || top[1].Count != 5 {
		t.Fatalf("phần tử thứ hai sai: got %+v", top[1])
	}
}

func TestTopKWithFewerKeysThanK(t *testing.T) {
	ts := NewTopKStore()
	ts.Increment("only-one")

	top := ts.TopK(5)
	if len(top) != 1 {
		t.Fatalf("kỳ vọng 1 phần tử khi chỉ có 1 key, got %d", len(top))
	}
}

func TestHistogramAvgAndP95(t *testing.T) {
	hs := NewHistogramStore([]string{"CreateSMContext"})
	// 100 mẫu latency đều 10ms, 5 mẫu latency 900ms -> p95 rơi vào vùng cao.
	for i := 0; i < 100; i++ {
		hs.Observe("CreateSMContext", 10)
	}
	for i := 0; i < 5; i++ {
		hs.Observe("CreateSMContext", 900)
	}

	snap := hs.Snapshot()
	if len(snap) != 1 {
		t.Fatalf("kỳ vọng 1 API trong snapshot, got %d", len(snap))
	}
	stat := snap[0]
	if stat.Count != 105 {
		t.Fatalf("count sai: got %d", stat.Count)
	}
	// 100/105 ~= 95.2% mẫu nằm ở bucket 10ms, nên p95 phải rơi rất sát
	// ngưỡng 10ms (không tụt về phía các mẫu 900ms hiếm gặp).
	if stat.P95MsEst < 9 || stat.P95MsEst > 10 {
		t.Fatalf("p95 ước lượng lệch khỏi vùng kỳ vọng ~10ms: got %f", stat.P95MsEst)
	}
}

func TestCounterErrorRate(t *testing.T) {
	cs := NewCounterStore([]string{"CreateSMContext"})
	cs.Observe("CreateSMContext", false)
	cs.Observe("CreateSMContext", false)
	cs.Observe("CreateSMContext", true)

	snap := cs.Snapshot()
	stat := snap[0]
	if stat.Total != 3 || stat.Errors != 1 {
		t.Fatalf("counter sai: got %+v", stat)
	}
	if stat.ErrRate < 0.33 || stat.ErrRate > 0.34 {
		t.Fatalf("error rate sai: got %f", stat.ErrRate)
	}
}
