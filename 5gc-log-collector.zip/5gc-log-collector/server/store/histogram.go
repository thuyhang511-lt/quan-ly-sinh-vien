package store

import "sync/atomic"

// bucketBoundsMs định nghĩa mốc trên (ms) của từng bucket độ trễ. Phần tử
// cuối cùng là bucket "vô cực" gom mọi giá trị lớn hơn mốc trước đó.
// Cố định trước để cập nhật histogram chỉ tốn O(1) (không cần tìm kiếm
// động), đổi lại p95 là giá trị xấp xỉ (nội suy trong bucket), không phải
// giá trị chính xác tuyệt đối — đánh đổi hợp lý ở tần suất ghi cao.
var bucketBoundsMs = []int64{5, 10, 20, 50, 100, 200, 500, 1000}

// numBuckets = số mốc cố định + 1 bucket "vô cực" gom mọi giá trị vượt mốc cuối.
var numBuckets = len(bucketBoundsMs) + 1

// apiHistogram giữ phân bố độ trễ của 1 API. buckets là slice (không phải
// mảng cố định) vì kích thước phụ thuộc numBuckets, được cấp phát 1 lần
// lúc khởi tạo và không bao giờ resize sau đó — an toàn dùng atomic song song.
type apiHistogram struct {
	buckets []atomic.Int64
	sum     atomic.Int64 // tổng latency, dùng tính trung bình
	count   atomic.Int64 // tổng số mẫu
}

func newAPIHistogram() *apiHistogram {
	return &apiHistogram{buckets: make([]atomic.Int64, numBuckets)}
}

// HistogramStore lưu histogram cho toàn bộ API, khởi tạo tĩnh giống CounterStore.
type HistogramStore struct {
	histograms map[string]*apiHistogram
}

func NewHistogramStore(apis []string) *HistogramStore {
	hs := &HistogramStore{histograms: make(map[string]*apiHistogram, len(apis))}
	for _, api := range apis {
		hs.histograms[api] = newAPIHistogram()
	}
	return hs
}

func bucketIndex(latencyMs int64) int {
	for i, bound := range bucketBoundsMs {
		if latencyMs <= bound {
			return i
		}
	}
	return numBuckets - 1
}

// Observe ghi nhận 1 giá trị latency cho api.
func (hs *HistogramStore) Observe(api string, latencyMs int64) {
	h, ok := hs.histograms[api]
	if !ok {
		return
	}
	h.buckets[bucketIndex(latencyMs)].Add(1)
	h.sum.Add(latencyMs)
	h.count.Add(1)
}

// LatencyStat là kết quả trung bình + p95 của 1 API.
type LatencyStat struct {
	API     string  `json:"api"`
	Count   int64   `json:"count"`
	AvgMs   float64 `json:"avg_ms"`
	P95MsEst float64 `json:"p95_ms_est"`
}

// percentile95 ước lượng mốc p95 bằng cách duyệt bucket theo thứ tự tăng
// dần cho tới khi số lượng cộng dồn vượt qua 95% tổng số mẫu, rồi nội suy
// tuyến tính trong khoảng [mốc dưới, mốc trên] của bucket đó.
// Độ phức tạp O(số bucket) — cố định, không phụ thuộc số lượng mẫu.
func percentile95(h *apiHistogram) float64 {
	total := h.count.Load()
	if total == 0 {
		return 0
	}
	target := float64(total) * 0.95

	var cumulative int64
	var lowerBound int64
	for i := 0; i < numBuckets; i++ {
		c := h.buckets[i].Load()
		nextCumulative := cumulative + c
		if float64(nextCumulative) >= target && c > 0 {
			upperBound := lastBoundOf(i)
			if upperBound < 0 {
				// bucket "vô cực": không nội suy được cận trên,
				// trả về chính cận dưới của bucket làm ước lượng an toàn.
				return float64(lowerBound)
			}
			fracInBucket := (target - float64(cumulative)) / float64(c)
			return float64(lowerBound) + fracInBucket*float64(upperBound-lowerBound)
		}
		cumulative = nextCumulative
		lowerBound = lastBoundOf(i)
	}
	return float64(lowerBound)
}

// lastBoundOf trả về mốc trên (ms) của bucket i, hoặc -1 nếu là bucket cuối (vô cực).
func lastBoundOf(i int) int64 {
	if i >= len(bucketBoundsMs) {
		return -1
	}
	return bucketBoundsMs[i]
}

// Snapshot trả về thống kê latency hiện tại của toàn bộ API.
func (hs *HistogramStore) Snapshot() []LatencyStat {
	out := make([]LatencyStat, 0, len(hs.histograms))
	for api, h := range hs.histograms {
		count := h.count.Load()
		var avg float64
		if count > 0 {
			avg = float64(h.sum.Load()) / float64(count)
		}
		out = append(out, LatencyStat{
			API:      api,
			Count:    count,
			AvgMs:    avg,
			P95MsEst: percentile95(h),
		})
	}
	return out
}
