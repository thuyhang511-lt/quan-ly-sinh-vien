// Package worker triển khai worker pool tách rời I/O (đọc TCP) khỏi phần
// xử lý CPU-bound (parse + cập nhật thống kê), theo đúng kiến trúc đã
// thiết kế: goroutine đọc chỉ đẩy dữ liệu thô vào channel, N worker cố
// định mới là nơi thực sự parse và ghi vào store.
package worker

import (
	"bytes"
	"log"
	"sync"

	"5gc-log-collector/protocol"
	"5gc-log-collector/server/store"
)

// Batch là 1 khối dữ liệu thô nhận được từ 1 lần đọc socket, có thể chứa
// nhiều dòng log gộp lại (client đã batch trước khi gửi).
type Batch []byte

// Pool là worker pool cố định N goroutine, tiêu thụ Batch từ 1 channel dùng chung.
type Pool struct {
	in         chan Batch
	store      *store.Store
	numWorkers int
	wg         sync.WaitGroup
}

// New khởi tạo pool với numWorkers worker, đọc từ 1 channel có buffer size
// bufferSize. bufferSize lớn giúp hấp thụ các đợt tải tăng đột biến mà
// không làm goroutine đọc TCP bị chặn ngay lập tức.
func New(numWorkers, bufferSize int, s *store.Store) *Pool {
	return &Pool{
		in:         make(chan Batch, bufferSize),
		store:      s,
		numWorkers: numWorkers,
	}
}

// Submit đẩy 1 batch dữ liệu thô vào hàng đợi xử lý. Gọi từ goroutine đọc
// TCP. Nếu channel đầy, lệnh gọi này sẽ chặn (backpressure có chủ đích)
// thay vì âm thầm drop log.
func (p *Pool) Submit(b Batch) {
	p.in <- b
}

// Start khởi động numWorkers goroutine xử lý, chạy tới khi channel đóng.
func (p *Pool) Start() {
	for i := 0; i < p.numWorkers; i++ {
		p.wg.Add(1)
		go p.runWorker()
	}
}

func (p *Pool) runWorker() {
	defer p.wg.Done()
	for batch := range p.in {
		p.processBatch(batch)
	}
}

// processBatch tách batch thành từng dòng bằng '\n' và parse riêng từng
// dòng, để 1 dòng lỗi không làm mất toàn bộ batch.
func (p *Pool) processBatch(batch Batch) {
	for _, line := range bytes.Split(batch, []byte("\n")) {
		if len(line) == 0 {
			continue
		}
		record, err := protocol.Parse(line)
		if err != nil {
			// log lỗi nhưng không dừng worker — dữ liệu bất thường từ 1
			// client không được phép làm sập cả server thu thập log.
			log.Printf("worker: bỏ qua dòng log không hợp lệ: %v", err)
			continue
		}
		p.store.Update(record)
	}
}

// Close đóng channel đầu vào và chờ toàn bộ worker xử lý xong phần còn lại
// trong hàng đợi — dùng khi shutdown server một cách an toàn.
func (p *Pool) Close() {
	close(p.in)
	p.wg.Wait()
}
