package protocol

import (
	"testing"
	"time"
)

func TestEncodeParseRoundTrip(t *testing.T) {
	original := LogRecord{
		Timestamp: time.Now(),
		NF:        "SMF",
		API:       "CreateSMContext",
		IMSI:      "001010000000123",
		Latency:   42,
		Status:    200,
	}

	encoded := Encode(original)
	// Encode luôn kết thúc bằng '\n'; Parse chỉ nhận dòng đã bỏ ký tự này,
	// giống hệt cách bufio.Scanner trả về ở phía server thật.
	line := encoded[:len(encoded)-1]

	got, err := Parse(line)
	if err != nil {
		t.Fatalf("Parse() lỗi không mong đợi: %v", err)
	}
	if got != original {
		t.Fatalf("round-trip không khớp: got=%+v want=%+v", got, original)
	}
}

func TestParseMissingField(t *testing.T) {
	_, err := Parse([]byte("nf=SMF;imsi=001010000000123"))
	if err == nil {
		t.Fatal("kỳ vọng lỗi khi thiếu field api, nhưng không có lỗi")
	}
}

func TestParseUnknownFieldIgnored(t *testing.T) {
	r, err := Parse([]byte("nf=AMF;api=RegistrationRequest;region=hn"))
	if err != nil {
		t.Fatalf("Parse() lỗi không mong đợi: %v", err)
	}
	if r.NF != "AMF" || r.API != "RegistrationRequest" {
		r2 := r
		t.Fatalf("parse sai giá trị: %+v", r2)
	}
}
