// Package protocol định nghĩa định dạng bản ghi log dùng chung giữa client
// (sinh log) và server (thu thập log), để hai bên luôn hiểu đúng dữ liệu
// của nhau mà không cần một schema phức tạp (JSON/Protobuf) ở tần suất cao.
package protocol

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// LogRecord mô tả một bản ghi log 5GC: NF nào gọi API nào, cho thuê bao
// nào, độ trễ xử lý bao nhiêu, và kết quả trả về ra sao.
type LogRecord struct {
	Timestamp time.Time // thời điểm ghi log
	NF        string    // tên network function: AMF, SMF, UDM, NEF...
	API       string    // tên API được gọi, phải thuộc danh sách hợp lệ của NF
	IMSI      string    // mã thuê bao (15 chữ số)
	Latency   int64     // độ trễ xử lý, milliseconds
	Status    int       // mã trạng thái HTTP-style: 200, 201, 400, 500...
}

// ValidAPIs liệt kê các NF hợp lệ và danh sách API tương ứng của từng NF.
// Dùng chung cho cả sinh log (client) lẫn kiểm tra tính hợp lệ khi cần.
var ValidAPIs = map[string][]string{
	"AMF": {"registration", "n1n2message_transfer", "ue_context_transfer", "ue_authentication"},
	"SMF": {"sm_context_create", "sm_context_update", "sm_context_release", "pdu_session_modify"},
	"NEF": {"monitoring_event_subscribe", "monitoring_event_unsubscribe", "pfd_management"},
	"UDM": {"subscriber_data_get", "ue_context_update", "subscription_data_subscribe"},
}

// NFList trả về danh sách NF hợp lệ, dùng khi cần random chọn 1 NF.
func NFList() []string {
	nfs := make([]string, 0, len(ValidAPIs))
	for nf := range ValidAPIs {
		nfs = append(nfs, nf)
	}
	return nfs
}

// Encode chuyển 1 LogRecord thành 1 dòng text dạng key=value;key=value...
// kết thúc bằng ký tự xuống dòng. Không dùng encoding/json để tránh chi phí
// reflect + allocation ở tần suất hàng chục nghìn record/giây.
const timeLayout = time.RFC3339

func Encode(r LogRecord) []byte {
	var b strings.Builder
	b.Grow(128)
	b.WriteString("timestamp=")
	b.WriteString(r.Timestamp.UTC().Format(timeLayout))
	b.WriteString(" nf=")
	b.WriteString(r.NF)
	b.WriteString(";api=")
	b.WriteString(r.API)
	b.WriteString(";imsi=")
	b.WriteString(r.IMSI)
	b.WriteString(" latency=")
	b.WriteString(strconv.FormatInt(r.Latency, 10))
	b.WriteString(";status=")
	b.WriteString(strconv.Itoa(r.Status))
	b.WriteByte('\n')
	return []byte(b.String())
}

// Parse tách 1 dòng text (đã bỏ ký tự xuống dòng) thành LogRecord.
// Cố tình không dùng regexp: ở tải cao, tách chuỗi thủ công bằng
// strings.Cut nhanh hơn nhiều và không cấp phát backtracking state.
func Parse(line []byte) (LogRecord, error) {
	var r LogRecord
	normalized := bytes.Join(bytes.Fields(line), []byte(";"))
	s := string(normalized)

	for s != "" {
		var field string
		field, s, _ = strings.Cut(s, ";")
		if field == "" {
			continue
		}
		key, val, ok := strings.Cut(field, "=")
		if !ok {
			return r, fmt.Errorf("protocol: invalid field %q", field)
		}
		switch key {
		case "timestamp":
			ts, err := time.Parse(timeLayout, val)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid timestamp %q: %w", val, err)
			}
			r.Timestamp = ts
		case "nf":
			r.NF = val
		case "api":
			r.API = val
		case "imsi":
			r.IMSI = val
		case "latency":
			lat, err := strconv.ParseInt(val, 10, 64)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid latency %q: %w", val, err)
			}
			r.Latency = lat
		case "status":
			code, err := strconv.Atoi(val)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid status %q: %w", val, err)
			}
			r.Status = code
		default:
			// bỏ qua field lạ để không phải nâng version protocol
			// mỗi khi thêm field mới không bắt buộc
		}
	}
	if r.NF == "" || r.API == "" {
		return r, fmt.Errorf("protocol: missing nf/api in line %q", line)
	}
	return r, nil
}

func Now() time.Time {
	return time.Now().UTC()
}
