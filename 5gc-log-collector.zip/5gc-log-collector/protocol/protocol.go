// Package protocol định nghĩa định dạng bản ghi log dùng chung giữa client
// (sinh log) và server (thu thập log), để hai bên luôn hiểu đúng dữ liệu
// của nhau mà không cần một schema phức tạp (JSON/Protobuf) ở tần suất cao.
package protocol

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

// LogRecord mô tả một bản ghi log 5GC: NF nào gọi API nào, cho thuê bao
// nào, độ trễ xử lý bao nhiêu, và kết quả trả về ra sao.
type LogRecord struct {
	NF     string // tên network function: AMF, SMF, UDM, NEF...
	API    string // tên API được gọi, phải thuộc danh sách hợp lệ của NF
	IMSI   string // mã thuê bao (15 chữ số)
	TSUnix int64  // thời điểm ghi log, unix milliseconds
	Lat    int64  // độ trễ xử lý, milliseconds
	Status int    // mã trạng thái HTTP-style: 200, 201, 400, 500...
}

// ValidAPIs liệt kê các NF hợp lệ và danh sách API tương ứng của từng NF.
// Dùng chung cho cả sinh log (client) lẫn kiểm tra tính hợp lệ khi cần.
var ValidAPIs = map[string][]string{
	"AMF": {"RegistrationRequest", "UEContextRelease", "HandoverRequest"},
	"SMF": {"CreateSMContext", "UpdateSMContext", "ReleaseSMContext"},
	"UDM": {"GetSubscriberData", "UpdateSubscriberData"},
	"NEF": {"NotifyEvent", "SubscribeEvent"},
}

// NFList trả về danh sách NF hợp lệ, dùng khi cần random chọn 1 NF.
func NFList() []string {
	nfs := make([]string, 0, len(ValidAPIs))
	for nf := range ValidAPIs {
		nfs = append(nfs, nf)
	}
	return nfs
}

// Encode chuyển 1 LogRecord thành 1 dòng text dạng key=value;key=value...
// kết thúc bằng ký tự xuống dòng. Không dùng encoding/json để tránh chi phí
// reflect + allocation ở tần suất hàng chục nghìn record/giây.
func Encode(r LogRecord) []byte {
	var b strings.Builder
	b.Grow(96)
	b.WriteString("nf=")
	b.WriteString(r.NF)
	b.WriteString(";api=")
	b.WriteString(r.API)
	b.WriteString(";imsi=")
	b.WriteString(r.IMSI)
	b.WriteString(";ts=")
	b.WriteString(strconv.FormatInt(r.TSUnix, 10))
	b.WriteString(";lat=")
	b.WriteString(strconv.FormatInt(r.Lat, 10))
	b.WriteString(";status=")
	b.WriteString(strconv.Itoa(r.Status))
	b.WriteByte('\n')
	return []byte(b.String())
}

// Parse tách 1 dòng text (đã bỏ ký tự xuống dòng) thành LogRecord.
// Cố tình không dùng regexp: ở tải cao, tách chuỗi thủ công bằng
// strings.Cut nhanh hơn nhiều và không cấp phát backtracking state.
func Parse(line []byte) (LogRecord, error) {
	var r LogRecord
	s := string(line)
	for s != "" {
		var field string
		field, s, _ = strings.Cut(s, ";")
		key, val, ok := strings.Cut(field, "=")
		if !ok {
			return r, fmt.Errorf("protocol: invalid field %q", field)
		}
		switch key {
		case "nf":
			r.NF = val
		case "api":
			r.API = val
		case "imsi":
			r.IMSI = val
		case "ts":
			ts, err := strconv.ParseInt(val, 10, 64)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid ts %q: %w", val, err)
			}
			r.TSUnix = ts
		case "lat":
			lat, err := strconv.ParseInt(val, 10, 64)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid lat %q: %w", val, err)
			}
			r.Lat = lat
		case "status":
			code, err := strconv.Atoi(val)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid status %q: %w", val, err)
			}
			r.Status = code
		default:
			// bỏ qua field lạ để không phải nâng version protocol
			// mỗi khi thêm field mới không bắt buộc
		}
	}
	if r.NF == "" || r.API == "" {
		return r, fmt.Errorf("protocol: missing nf/api in line %q", line)
	}
	return r, nil
}

// NowMillis là helper dùng chung để lấy timestamp hiện tại theo ms.
func NowMillis() int64 {
	return time.Now().UnixMilli()
}
