// Package protocol định nghĩa định dạng bản ghi log dùng chung giữa client
// (sinh log) và server (thu thập log), khớp chính xác với định dạng trong
// đề bài:
//
//	timestamp=2026-07-28T10:01:05Z nf=SMF;api=sm_context_create;imsi=452040000000001 latency=120;status=200
package protocol

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// LogRecord mô tả một bản ghi log 5GC: NF nào gọi API nào, cho thuê bao
// nào, độ trễ xử lý bao nhiêu, và kết quả trả về ra sao.
type LogRecord struct {
	Timestamp time.Time // thời điểm phát sinh sự kiện
	NF        string    // chức năng mạng: AMF, SMF, NEF, UDM
	API       string    // tên API được gọi, phải thuộc danh sách hợp lệ của NF
	IMSI      string    // định danh thuê bao
	Latency   int64     // thời gian phản hồi, milliseconds
	Status    int       // kết quả phản hồi: 200, 201, 400, 500...
}

// ValidAPIs liệt kê đúng danh sách NF và API hợp lệ theo đề bài.
var ValidAPIs = map[string][]string{
	"AMF": {"registration", "n1n2message_transfer", "ue_context_transfer", "ue_authentication"},
	"SMF": {"sm_context_create", "sm_context_update", "sm_context_release", "pdu_session_modify"},
	"NEF": {"monitoring_event_subscribe", "monitoring_event_unsubscribe", "pfd_management"},
	"UDM": {"subscriber_data_get", "ue_context_update", "subscription_data_subscribe"},
}

// NFList trả về danh sách NF hợp lệ, dùng khi cần random chọn 1 NF.
func NFList() []string {
	nfs := make([]string, 0, len(ValidAPIs))
	for nf := range ValidAPIs {
		nfs = append(nfs, nf)
	}
	return nfs
}

// timeLayout khớp đúng định dạng ISO8601/RFC3339 trong ví dụ của đề bài
// (2026-07-28T10:01:05Z).
const timeLayout = time.RFC3339

// Encode chuyển 1 LogRecord thành 1 dòng text đúng định dạng đề bài: các
// nhóm field cách nhau bằng khoảng trắng, trong mỗi nhóm các field cách
// nhau bằng ';'. Kết thúc bằng ký tự xuống dòng.
func Encode(r LogRecord) []byte {
	var b strings.Builder
	b.Grow(128)
	b.WriteString("timestamp=")
	b.WriteString(r.Timestamp.UTC().Format(timeLayout))
	b.WriteString(" nf=")
	b.WriteString(r.NF)
	b.WriteString(";api=")
	b.WriteString(r.API)
	b.WriteString(";imsi=")
	b.WriteString(r.IMSI)
	b.WriteString(" latency=")
	b.WriteString(strconv.FormatInt(r.Latency, 10))
	b.WriteString(";status=")
	b.WriteString(strconv.Itoa(r.Status))
	b.WriteByte('\n')
	return []byte(b.String())
}

// Parse tách 1 dòng text (đã bỏ ký tự xuống dòng) thành LogRecord.
//
// Định dạng đề bài trộn 2 loại dấu phân tách: khoảng trắng giữa các nhóm
// field, ';' giữa các field trong cùng 1 nhóm. Để không phải biết trước
// thứ tự nhóm, ta chuẩn hoá dòng bằng cách thay mọi khoảng trắng thành
// ';' rồi tách đồng nhất bằng 1 vòng lặp duy nhất — cách này chấp nhận
// cả dòng có nhiều khoảng trắng liên tiếp, và không phụ thuộc field nào
// nằm trong nhóm nào.
func Parse(line []byte) (LogRecord, error) {
	var r LogRecord
	normalized := bytes.Join(bytes.Fields(line), []byte(";"))
	s := string(normalized)

	for s != "" {
		var field string
		field, s, _ = strings.Cut(s, ";")
		if field == "" {
			continue
		}
		key, val, ok := strings.Cut(field, "=")
		if !ok {
			return r, fmt.Errorf("protocol: invalid field %q", field)
		}
		switch key {
		case "timestamp":
			ts, err := time.Parse(timeLayout, val)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid timestamp %q: %w", val, err)
			}
			r.Timestamp = ts
		case "nf":
			r.NF = val
		case "api":
			r.API = val
		case "imsi":
			r.IMSI = val
		case "latency":
			lat, err := strconv.ParseInt(val, 10, 64)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid latency %q: %w", val, err)
			}
			r.Latency = lat
		case "status":
			code, err := strconv.Atoi(val)
			if err != nil {
				return r, fmt.Errorf("protocol: invalid status %q: %w", val, err)
			}
			r.Status = code
		default:
			// bỏ qua field lạ để không phải nâng version protocol
			// mỗi khi thêm field mới không bắt buộc
		}
	}
	if r.NF == "" || r.API == "" {
		return r, fmt.Errorf("protocol: missing nf/api in line %q", line)
	}
	return r, nil
}

// Now là helper dùng chung để lấy thời điểm hiện tại (UTC) khi sinh log.
func Now() time.Time {
	return time.Now().UTC()
}
